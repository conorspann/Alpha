
#include "command.h"

#include <string>
#include <vector>
#include <iostream>

Command::Command(std::vector<std::string> p):
    params(p)
{
    opMap.insert(std::pair<char, operation>('+', add));
    opMap.insert(std::pair<char, operation>('-', subtract));
    opMap.insert(std::pair<char, operation>('*', multiply));
    opMap.insert(std::pair<char, operation>('/', divide));
    opMap.insert(std::pair<char, operation>('%', remainder));
}

bool Command::hasCorrectNumParams()
{
    return params.size() == getNumParams();
}

bool Command::isValid(std::string param)
{
    /** TODO: IMPLEMENT */
    return true;
}

/**
     TODO: Integrate std::string property into isVariable, resolve, calculate and in other files etc

*/

std::string Command::isVariable(std::string param, const std::map<std::string, std::pair<std::string, int>> * globalDataPool)
{
    std::string value(param);
    if(param[0] == '@'){
        std::string identifier = param.substr(1, std::string::npos);
        std::map<std::string, std::pair<std::string, int>>::const_iterator it;
        it = globalDataPool->find(identifier);
        if(it != globalDataPool->end()){
            value = it->second.first;
        }else{
            value = "Null";
        }
    }

    return value;
}

std::string Command::resolve(std::string paramStr,  const std::map<std::string, std::pair<std::string, int>> * globalDataPool)
{
    return calculate(parseParam(paramStr, globalDataPool));
}

/**
    REFACTOR !!
*/
std::vector<std::string> Command::parseParam(std::string param, const std::map<std::string, std::pair<std::string, int>> * globalDataPool)
{
    std::vector<std::string> parsedParam;
    std::string val;
    bool isString = false;
    for(int i = 0; i < param.length(); i++){
        char c = param[i];
        // need to check if params are valid numbers variables or symbols otherwise throw error
        if(c == '\"'){
            isString = !isString;
        }
        if(isSymbol(c) && !isString){
            val = isVariable(val, globalDataPool);
            if(val == "Null"){
                throw std::runtime_error("Error: Null variable in command.");
            }
            std::string pol(val);
            parsedParam.push_back(pol);
            std::string symbol(std::string(1, c));
            parsedParam.push_back(symbol);
            val = "";
            continue;
        }else if(i == param.length() - 1){
            if(c != '\"'){
                val += c;
            }
            val = isVariable(val, globalDataPool);
            if(val == "Null"){
                throw std::runtime_error("Error: Null variable in command.");
            }
            std::string pol(val);
            parsedParam.push_back(pol);
            break;
        }
        if(c != '\"'){
            val += c;
        }
    }

    return parsedParam;
}

bool Command::isSymbol(char c)
{
    std::map<char, operation>::iterator it = opMap.find(c);
    if(it != opMap.end()){
        return true;
    }

    return false;
}

std::string Command::calculate(std::vector<std::string> params)
{
    std::string result(params[0]);
    if(params.size() > 1){
        int r = 0;
        void (Command::*currentOp)(int*, int) = add;
        for(auto i : params){
            if(isSymbol(i[0])){ /** && if length == 1 ??  */
                std::map<char, operation>::iterator it = opMap.find(i[0]);
                if(it != opMap.end()){
                    currentOp = it->second;
                }
                continue;
            }
            /** TODO: Enable string/int etc concatenation */
            //  for now bomb out an error if string cant be converted to int
            if(i.find_first_not_of("0123456789") != std::string::npos){
                /** Refactor formatting */
                std::string errMsg = "Error: Cannot calculate using non-numeric value: " + i + " In expression: ";
                for(auto j : params){
                    errMsg += j;
                }
                throw std::runtime_error(errMsg);
            }
            (this->*currentOp)(&r, std::stoi(i)); // doesn't work for strings
            /**
                maybe always set the first param to result first i.e. no add DONE=Y
                also make concatenation operator for string/int additions    DONE=N
                otherwise throw type/wrong operator exception                DONE=N

                if cannot be converted to int

                WARNING: if do decide to use concatenation operator, beware of the '.''s in decimals
                i.e. 3.2 != 3 concatenate 2
            */
        }
        result = std::to_string(r);
    }

    return result;
}

void Command::add(int * total, int value)
{
    *total += value;
}

void Command::subtract(int * total, int value)
{
    *total -= value;
}

void Command::multiply(int * total, int value)
{
    *total *= value;
}

void Command::divide(int * total, int value)
{
    *total /= value;
}

void Command::remainder(int * total, int value)
{
    *total %= value;
}
