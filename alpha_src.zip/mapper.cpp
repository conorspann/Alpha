
#include "mapper.h"
#include "command.h"
#include "console_out.h"
#include "console_in.h"
#include "assign.h"
#include "memory_dump.h"
#include "if.h"
#include "endif.h"

#include <exception>
#include <stdexcept>
#include <iostream>
#include <string>

std::unique_ptr<Command> Mapper::getNewCommand(std::string line, std::vector<std::string> params)
{
    //could potentially re write using a map of string->function pointers
    //functions return type of oommand
    //std::unique_ptr<Command> (*p)(std::vector<std::string>);
    //could initialise in constructor
    //however may be more complicated than all the if's
// refactor
// maybe do upppercase and lowercase ??
    if(line == "@"){
        std::unique_ptr<Command> c = std::make_unique<Assign>(params);
        return std::move(checkParams(std::move(c)));
    }else if(line == "ConsoleOut"){
        std::unique_ptr<Command> c = std::make_unique<ConsoleOut>(params);
        return std::move(checkParams(std::move(c)));
    }else if(line == "ConsoleIn"){
        std::unique_ptr<Command> c = std::make_unique<ConsoleIn>(params);
        return std::move(checkParams(std::move(c)));
    }else if(line == "MemoryDump"){
        std::unique_ptr<Command> c = std::make_unique<MemoryDump>(params);
        return std::move(checkParams(std::move(c)));
    }else if(line == "If"){
        std::unique_ptr<Command> c = std::make_unique<If>(params);
        return std::move(checkParams(std::move(c)));
    }else if(line == "EndIf"){
        std::unique_ptr<Command> c = std::make_unique<EndIf>(params);
        return std::move(checkParams(std::move(c)));
    }
    throw std::runtime_error("Exception: Command \"" + line + "\" not valid");
}

std::unique_ptr<Command> Mapper::checkParams(std::unique_ptr<Command> c)
{
    if(!c->hasCorrectNumParams()){
        throw std::runtime_error("Command: " + c->getName() + " requires " + std::to_string(c->getNumParams()) + " params.");
    }
    return std::move(c);
}
