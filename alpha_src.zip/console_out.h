
#include "command.h"

#include <string>
#include <memory>

class ConsoleOut: public Command{
public:
    ConsoleOut(std::vector<std::string>);
    void execute(std::map<std::string, std::pair<std::string, int>> *, std::vector<std::unique_ptr<Command>> &, int *);
    int getNumParams();
    std::string getName();
};

