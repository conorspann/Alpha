
#ifndef MAPPER_H
#define MAPPER_H

#include "command.h"
#include <map>
#include <string>
#include <memory>

class Mapper{
public:
    std::unique_ptr<Command> getNewCommand(std::string, std::vector<std::string>);
    std::unique_ptr<Command> checkParams(std::unique_ptr<Command>);
};

#endif // MAPPER_H
