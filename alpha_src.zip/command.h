
#ifndef COMMAND_H
#define COMMAND_H

#include <string>
#include <vector>
#include <map>
#include <memory>

class Command{
public:
    Command(std::vector<std::string>);
    virtual void execute(std::map<std::string, std::pair<std::string, int>> *, std::vector<std::unique_ptr<Command>> &, int *) =0;
    virtual int getNumParams() =0;
    virtual std::string getName() =0;
    bool hasCorrectNumParams();
protected:
    enum Type{
        STRING,
        INT,
        FLOAT
    };
    std::vector<std::string> params;
    bool isValid(std::string);
    std::string isVariable(std::string, const std::map<std::string, std::pair<std::string, int>> *);
    std::string resolve(std::string, const std::map<std::string, std::pair<std::string, int>> *);
private:
    typedef void (Command::*operation)(int*,int);
    std::map<char, operation> opMap;
    std::vector<std::string> parseParam(std::string, const std::map<std::string, std::pair<std::string, int>> *);
    bool isSymbol(char);
    std::string calculate(std::vector<std::string>);
    void add(int*, int);
    void subtract(int*, int);
    void multiply(int*, int);
    void divide(int*, int);
    void remainder(int*, int);
};

#endif // COMMAND_H
